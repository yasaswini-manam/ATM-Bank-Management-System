package atm.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class FundTransfer extends JFrame implements ActionListener {
    JLabel l1, l2, l3, l4, l5;
    JTextField t1, t2, t3;
    JComboBox<String> c1;
    JButton b1, b2;

    FundTransfer() {
        setTitle("Fund Transfer");

        // Labels
        l1 = new JLabel("Fund Transfer");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));

        l2 = new JLabel("Transfer Type:");
        l2.setFont(new Font("Raleway", Font.BOLD, 18));

        l3 = new JLabel("To Account Number:");
        l3.setFont(new Font("Raleway", Font.BOLD, 18));

        l4 = new JLabel("Amount to Transfer:");
        l4.setFont(new Font("Raleway", Font.BOLD, 18));

        l5 = new JLabel("From Account Number:");
        l5.setFont(new Font("Raleway", Font.BOLD, 18));

        // Text Fields
        t1 = new JTextField(); // To Account
        t1.setFont(new Font("Raleway", Font.BOLD, 14));

        t2 = new JTextField(); // Amount
        t2.setFont(new Font("Raleway", Font.BOLD, 14));

        t3 = new JTextField(); // From Account
        t3.setFont(new Font("Raleway", Font.BOLD, 14));

        // ComboBox for transfer type
        String[] transferTypes = {"Internal Transfer", "External Transfer"};
        c1 = new JComboBox<>(transferTypes);
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Raleway", Font.BOLD, 14));

        // Buttons
        b1 = new JButton("Transfer");
        b1.setFont(new Font("Raleway", Font.BOLD, 14));
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);

        b2 = new JButton("Cancel");
        b2.setFont(new Font("Raleway", Font.BOLD, 14));
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);

        // Layout
        setLayout(null);

        l1.setBounds(200, 30, 300, 40);
        add(l1);

        l2.setBounds(100, 100, 150, 30);
        add(l2);
        c1.setBounds(300, 100, 200, 30);
        add(c1);

        l3.setBounds(100, 160, 200, 30);
        add(l3);
        t1.setBounds(300, 160, 200, 30);
        add(t1);

        l4.setBounds(100, 220, 200, 30);
        add(l4);
        t2.setBounds(300, 220, 200, 30);
        add(t2);

        l5.setBounds(100, 280, 200, 30);
        add(l5);
        t3.setBounds(300, 280, 200, 30);
        add(t3);

        b1.setBounds(150, 350, 120, 30);
        add(b1);
        b2.setBounds(300, 350, 120, 30);
        add(b2);

        b1.addActionListener(this);
        b2.addActionListener(this);

        getContentPane().setBackground(Color.WHITE);
        setSize(600, 450);
        setLocation(300, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String transferType = (String) c1.getSelectedItem();
        String toAccount = t1.getText().trim();
        String amount = t2.getText().trim();
        String fromAccount = t3.getText().trim();

        if (ae.getSource() == b1) {
            if (fromAccount.equals("") || toAccount.equals("") || amount.equals("")) {
                JOptionPane.showMessageDialog(null, "Please fill all fields.");
                return;
            }

            try {
                double transferAmount = Double.parseDouble(amount);
                Conn conn = new Conn();

                if (transferType.equals("Internal Transfer")) {
                    // Check if both accounts exist
                    String checkFrom = "SELECT balance FROM users WHERE account_number = '" + fromAccount + "'";
                    String checkTo = "SELECT * FROM users WHERE account_number = '" + toAccount + "'";

                    ResultSet rsFrom = conn.s.executeQuery(checkFrom);
                    if (!rsFrom.next()) {
                        JOptionPane.showMessageDialog(null, "Sender account does not exist.");
                        return;
                    }

                    double senderBalance = rsFrom.getDouble("balance");
                    if (senderBalance < transferAmount) {
                        JOptionPane.showMessageDialog(null, "Insufficient Balance.");
                        return;
                    }

                    ResultSet rsTo = conn.s.executeQuery(checkTo);
                    if (!rsTo.next()) {
                        JOptionPane.showMessageDialog(null, "Receiver account does not exist.");
                        return;
                    }

                    String query1 = "UPDATE users SET balance = balance - " + transferAmount + " WHERE account_number = '" + fromAccount + "'";
                    String query2 = "UPDATE users SET balance = balance + " + transferAmount + " WHERE account_number = '" + toAccount + "'";
                    conn.s.executeUpdate(query1);
                    conn.s.executeUpdate(query2);
                    JOptionPane.showMessageDialog(null, "Amount Transferred Successfully.");
                }

                else if (transferType.equals("External Transfer")) {
                    String query = "INSERT INTO external_transfers (from_account, to_account, amount) VALUES ('" + fromAccount + "', '" + toAccount + "', " + transferAmount + ")";
                    conn.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "External Transfer Request Submitted.");
                }

            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            }

        } else if (ae.getSource() == b2) {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new FundTransfer().setVisible(true);
    }
}
