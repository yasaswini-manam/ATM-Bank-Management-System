package atm.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SelectAction extends JFrame implements ActionListener {
    JButton transactionButton, fundTransferButton;
    String pin;

    SelectAction(String pin) {
        this.pin = pin;

        setTitle("Select Action");
        setLayout(null);
        setSize(500, 300);
        setLocationRelativeTo(null); // center on screen

        JLabel label = new JLabel("Select an option:");
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setBounds(150, 30, 300, 30);
        add(label);

        transactionButton = new JButton("Transaction");
        transactionButton.setBounds(150, 80, 200, 40);
        transactionButton.addActionListener(this);
        add(transactionButton);

        fundTransferButton = new JButton("Fund Transfer");
        fundTransferButton.setBounds(150, 140, 200, 40);
        fundTransferButton.addActionListener(this);
        add(fundTransferButton);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == transactionButton) {
            setVisible(false);
            new Transactions(pin).setVisible(true); // assuming this exists
        } else if (ae.getSource() == fundTransferButton) {
            setVisible(false);
            new FundTransfer(pin).setVisible(true); // create this class separately
        }
    }
    public static void main(String[] args) {
        new SelectAction().setVisible(true);
    }
}
