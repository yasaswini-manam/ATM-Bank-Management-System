
package atm.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.io.File;
import java.io.FileWriter;

public class MiniStatement extends JFrame implements ActionListener{
 
    JButton b1, b2;
    JLabel l1;
    StringBuilder statementContent = new StringBuilder();
    MiniStatement(String pin){
        super("Mini Statement");
        getContentPane().setBackground(Color.WHITE);
        setSize(400,600);
        setLocation(20,20);
        
        l1 = new JLabel();
        add(l1);
        
        JLabel l2 = new JLabel("Indian Bank");
        l2.setBounds(150, 20, 100, 20);
        add(l2);
        
        JLabel l3 = new JLabel();
        l3.setBounds(20, 80, 300, 20);
        add(l3);
        
        JLabel l4 = new JLabel();
        l4.setBounds(20, 400, 300, 20);
        add(l4);
        
        try{
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from login where pin = '"+pin+"'");
            while(rs.next()){
                String card =rs.getString("cardno");
      
                l3.setText("Card Number:    " + rs.getString("cardno").substring(0, 4) + "XXXXXXXX" + rs.getString("cardno").substring(12));
                statementContent.append(l3.getText()).append("\n\n");
            }
        }catch(Exception e){}
        	 
        try{
            int balance = 0;
            Conn c1  = new Conn();
            ResultSet rs = c1.s.executeQuery("SELECT * FROM bank where pin = '"+pin+"'");
            while(rs.next()){
                String line=rs.getString("date")+"   "+rs.getString("mode")+"   "+rs.getString("amount");
                l1.setText(l1.getText() + "<html>"+rs.getString("date")+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("mode") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("amount") + "<br><br><html>");
                if(rs.getString("mode").equals("Deposit")){
                    balance += Integer.parseInt(rs.getString("amount"));
                }else{
                    balance -= Integer.parseInt(rs.getString("amount"));
                }
            }
            String balText="Your total balance is Rs"+balance;
            l4.setText(balText);
            statementContent.append("\n").append(balText);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        setLayout(null);
        b1=new JButton("Exit");
        b2=new JButton("Print");
        add(b1);
        add(b2);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
        l1.setBounds(20, 140, 400, 200);
        b1.setBounds(20, 500, 100, 25);
        b2.setBounds(140,500,100,25);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1)
        {
            this.setVisible(false);
        }
        else if(ae.getSource()==b2)
        {
            try
            {
                JFileChooser fileChooser=new JFileChooser();
                fileChooser.setSelectedFile(new File("MiniStatement.txt"));
                int option =fileChooser.showSaveDialog(this);
                if(option ==JFileChooser.APPROVE_OPTION)
                {
                    File file=fileChooser.getSelectedFile();
                    try(FileWriter fw = new FileWriter(file))
                    {
                      fw.write(statementContent.toString());
                      JOptionPane.showMessageDialog(this,"Statement saved to "+file.getAbsolutePath());
                    }
                }       
            }catch(Exception e)
            {
                e.printStackTrace();
            }
            }
    }
    
    public static void main(String[] args){
        new MiniStatement("").setVisible(true);
    }
    
}